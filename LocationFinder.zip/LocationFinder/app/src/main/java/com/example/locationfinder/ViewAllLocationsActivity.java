package com.example.locationfinder;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ViewAllLocationsActivity extends AppCompatActivity {

    private RecyclerView recyclerViewLocations;
    private LocationAdapter locationAdapter;
    private DatabaseHelper db;
    private ArrayList<Location> locationList;
    private Button btnBack; // Back button

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_locations);

        recyclerViewLocations = findViewById(R.id.recyclerViewLocations);
        btnBack = findViewById(R.id.btnBack); // Initialize the back button
        db = new DatabaseHelper(this);
        locationList = new ArrayList<>();

        loadLocations();

        locationAdapter = new LocationAdapter(this, locationList);
        recyclerViewLocations.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewLocations.setAdapter(locationAdapter);

        // Set up click listener for the back button
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Finish this activity and return to the previous one
            }
        });
    }

    private void loadLocations() {
        Cursor cursor = db.getAllLocations();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COL_ID));
                String address = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_ADDRESS));
                double latitude = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COL_LATITUDE));
                double longitude = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COL_LONGITUDE));

                locationList.add(new Location(id, address, latitude, longitude));
            }
            cursor.close();
        } else {
            Toast.makeText(this, "No locations found", Toast.LENGTH_SHORT).show();
        }
    }
}


