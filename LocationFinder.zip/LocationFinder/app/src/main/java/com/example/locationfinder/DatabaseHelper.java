package com.example.locationfinder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper class for the LocationFinder app
 * Manages SQLite database operations for storing and retrieving location data
 * in the Greater Toronto Area (GTA)
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database constants
    private static final String DATABASE_NAME = "LocationFinder.db";
    private static final String TABLE_NAME = "location_table";
    public static final String COL_ID = "id";  // Changed to public for access in MainActivity
    public static final String COL_ADDRESS = "address";
    public static final String COL_LATITUDE = "latitude";
    public static final String COL_LONGITUDE = "longitude";
    private static final int DATABASE_VERSION = 1;

    /**
     * Constructor for DatabaseHelper
     * @param context The application context
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the locations table
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ADDRESS + " TEXT UNIQUE, " +
                COL_LATITUDE + " REAL, " +
                COL_LONGITUDE + " REAL)";
        db.execSQL(createTableQuery);

        // Populate with a few sample data points for demonstration
        populateSampleData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /**
     * Query location by address (case-insensitive)
     * @param address The address to search for
     * @return Cursor containing matching location data
     */
    public Cursor getLocationByAddress(String address) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME +
                " WHERE LOWER(" + COL_ADDRESS + ") LIKE LOWER(?)";
        return db.rawQuery(query, new String[]{"%" + address + "%"});
    }

    /**
     * Get all locations in the database
     * @return Cursor containing all location data
     */
    public Cursor getAllLocations() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " ORDER BY " + COL_ADDRESS, null);
    }

    /**
     * Insert a new location
     * @param address Location address
     * @param latitude Location latitude
     * @param longitude Location longitude
     * @return true if insertion was successful
     */
    public boolean insertLocation(String address, double latitude, double longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_ADDRESS, address);
        contentValues.put(COL_LATITUDE, latitude);
        contentValues.put(COL_LONGITUDE, longitude);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    /**
     * Update an existing location
     * @param id Location ID
     * @param address New address
     * @param latitude New latitude
     * @param longitude New longitude
     * @return true if update was successful
     */
    public boolean updateLocation(int id, String address, double latitude, double longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_ADDRESS, address);
        contentValues.put(COL_LATITUDE, latitude);
        contentValues.put(COL_LONGITUDE, longitude);
        int result = db.update(TABLE_NAME, contentValues, COL_ID + " = ?",
                new String[]{String.valueOf(id)});
        return result > 0;
    }

    /**
     * Delete a location by ID
     * @param id Location ID to delete
     * @return number of rows affected
     */
    public int deleteLocation(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, COL_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    /**
     * Populate database with a few sample GTA locations for demonstration purposes
     * @param db SQLiteDatabase instance
     */
    private void populateSampleData(SQLiteDatabase db) {
        // Core Toronto locations
        insertSampleLocation(db, "CN Tower, Toronto", 43.6426, -79.3871);
        insertSampleLocation(db, "Rogers Centre, Toronto", 43.6418, -79.3891);
        insertSampleLocation(db, "Art Gallery of Ontario, Toronto", 43.6536, -79.3925);
        insertSampleLocation(db, "Royal Ontario Museum, Toronto", 43.6677, -79.3947);
        insertSampleLocation(db, "St. Lawrence Market, Toronto", 43.6484, -79.3714);
        insertSampleLocation(db, "Toronto Islands", 43.6205, -79.3782);
        insertSampleLocation(db, "Distillery District, Toronto", 43.6503, -79.3595);
        insertSampleLocation(db, "High Park, Toronto", 43.6465, -79.4637);
        insertSampleLocation(db, "Ontario Place, Toronto", 43.6280, -79.4152);
        insertSampleLocation(db, "Evergreen Brick Works, Toronto", 43.6846, -79.3656);

        // Scarborough locations
        insertSampleLocation(db, "Scarborough Town Centre", 43.7754, -79.2577);
        insertSampleLocation(db, "Toronto Zoo", 43.8177, -79.1859);
        insertSampleLocation(db, "Scarborough Bluffs", 43.7054, -79.2350);
        insertSampleLocation(db, "University of Toronto Scarborough", 43.7848, -79.1893);
        insertSampleLocation(db, "Guildwood Park", 43.7553, -79.1984);

        // Mississauga locations
        insertSampleLocation(db, "Square One Shopping Centre, Mississauga", 43.5934, -79.6416);
        insertSampleLocation(db, "Port Credit, Mississauga", 43.5515, -79.5832);
        insertSampleLocation(db, "Erindale Park, Mississauga", 43.5553, -79.6522);
        insertSampleLocation(db, "Mississauga Celebration Square", 43.5890, -79.6441);
        insertSampleLocation(db, "Streetsville, Mississauga", 43.5815, -79.7111);
        insertSampleLocation(db, "Rattray Marsh Conservation Area", 43.5172, -79.6272);
        insertSampleLocation(db, "Kariya Park, Mississauga", 43.5912, -79.6397);
        insertSampleLocation(db, "Lakefront Promenade Park, Mississauga", 43.5613, -79.5599);

        // Brampton locations
        insertSampleLocation(db, "Gage Park, Brampton", 43.6857, -79.7600);
        insertSampleLocation(db, "Rose Theatre, Brampton", 43.6863, -79.7595);
        insertSampleLocation(db, "Brampton City Hall", 43.6850, -79.7598);
        insertSampleLocation(db, "Heart Lake Conservation Park", 43.7370, -79.8148);
        insertSampleLocation(db, "Professor's Lake, Brampton", 43.7441, -79.7287);

        // Vaughan locations
        insertSampleLocation(db, "Vaughan Mills Shopping Centre", 43.8226, -79.5362);
        insertSampleLocation(db, "Canada's Wonderland", 43.8430, -79.5390);
        insertSampleLocation(db, "Kortright Centre for Conservation", 43.8335, -79.6113);
        insertSampleLocation(db, "Boyd Conservation Park", 43.8077, -79.6107);
        insertSampleLocation(db, "Black Creek Pioneer Village", 43.7735, -79.5258);

        // Richmond Hill locations
        insertSampleLocation(db, "David Dunlap Observatory, Richmond Hill", 43.8602, -79.4232);
        insertSampleLocation(db, "Richmond Green Sports Centre", 43.8926, -79.3883);
        insertSampleLocation(db, "Lake Wilcox Park", 43.9425, -79.4275);
        insertSampleLocation(db, "Mill Pond Park, Richmond Hill", 43.8818, -79.4414);
        insertSampleLocation(db, "Richmond Hill Heritage Centre", 43.8769, -79.4376);

        // Markham locations
        insertSampleLocation(db, "Main Street Unionville, Markham", 43.8668, -79.3091);
        insertSampleLocation(db, "Markville Shopping Centre", 43.8673, -79.3044);
        insertSampleLocation(db, "Toogood Pond Park", 43.8692, -79.3187);
        insertSampleLocation(db, "Pacific Mall, Markham", 43.8260, -79.3050);
        insertSampleLocation(db, "Angus Glen Golf Club, Markham", 43.9027, -79.3318);
        insertSampleLocation(db, "Markham Museum", 43.9009, -79.2657);

        // Oakville locations
        insertSampleLocation(db, "Bronte Creek Provincial Park, Oakville", 43.4148, -79.7497);
        insertSampleLocation(db, "Oakville Museum at Erchless Estate", 43.4446, -79.6704);
        insertSampleLocation(db, "Glen Abbey Golf Club, Oakville", 43.4345, -79.7166);
        insertSampleLocation(db, "Lions Valley Park, Oakville", 43.4618, -79.7427);
        insertSampleLocation(db, "Coronation Park, Oakville", 43.4236, -79.7027);

        // Ajax and Pickering locations
        insertSampleLocation(db, "Rotary Park, Ajax", 43.8242, -79.0298);
        insertSampleLocation(db, "Pickering Town Centre", 43.8390, -79.0882);
        insertSampleLocation(db, "Frenchman's Bay, Pickering", 43.8107, -79.0901);
        insertSampleLocation(db, "Ajax Waterfront Park", 43.8260, -79.0318);
        insertSampleLocation(db, "Petticoat Creek Conservation Area", 43.7948, -79.0922);

        // Oshawa locations
        insertSampleLocation(db, "Parkwood Estate, Oshawa", 43.8975, -78.8675);
        insertSampleLocation(db, "Lakeview Park, Oshawa", 43.8771, -78.8314);
        insertSampleLocation(db, "Oshawa Valley Botanical Gardens", 43.8997, -78.8593);
        insertSampleLocation(db, "Canadian Automotive Museum, Oshawa", 43.8962, -78.8658);
        insertSampleLocation(db, "Oshawa Centre", 43.8781, -78.8661);

        // Additional Toronto locations
        insertSampleLocation(db, "Toronto Eaton Centre", 43.6544, -79.3807);
        insertSampleLocation(db, "Bata Shoe Museum, Toronto", 43.6676, -79.4003);
        insertSampleLocation(db, "Yonge-Dundas Square, Toronto", 43.6561, -79.3802);
        insertSampleLocation(db, "Fort York National Historic Site", 43.6373, -79.4064);
        insertSampleLocation(db, "Woodbine Beach, Toronto", 43.6667, -79.2989);

        // Additional suburban locations
        insertSampleLocation(db, "Milton Sports Centre, Milton", 43.5125, -79.8972);
        insertSampleLocation(db, "Lion's Head, Halton Hills", 43.7025, -79.9572);
        insertSampleLocation(db, "Rockwood Conservation Area", 43.6250, -80.1409);
        insertSampleLocation(db, "Albion Falls, Hamilton", 43.1882, -79.8116);
        insertSampleLocation(db, "Niagara Falls", 43.0896, -79.0849);
        insertSampleLocation(db, "Royal Botanical Gardens, Burlington", 43.2916, -79.8777);
        insertSampleLocation(db, "Bruce Trail, Halton Hills", 43.6706, -79.9605);

        // Remaining locations
        insertSampleLocation(db, "Hilton Falls Conservation Area, Milton", 43.5083, -79.9746);
        insertSampleLocation(db, "Lake Aquitaine Park, Mississauga", 43.5856, -79.7436);
        insertSampleLocation(db, "Spencer Gorge/Webster's Falls Conservation Area", 43.2699, -79.9737);
        insertSampleLocation(db, "Terra Cotta Conservation Area", 43.7100, -79.9591);
        insertSampleLocation(db, "Toronto Music Garden", 43.6365, -79.3966);
        insertSampleLocation(db, "Sunnybrook Park, Toronto", 43.7173, -79.3557);
        insertSampleLocation(db, "Trinity Bellwoods Park, Toronto", 43.6473, -79.4185);
        insertSampleLocation(db, "Leslie Street Spit", 43.6275, -79.3407);
        insertSampleLocation(db, "Ward's Island Beach, Toronto Islands", 43.6229, -79.3655);
        insertSampleLocation(db, "Rouge National Urban Park", 43.8200, -79.1747);

        // Final locations for a full 100
        insertSampleLocation(db, "Albion Hills Conservation Area", 43.9808, -79.8492);
        insertSampleLocation(db, "Mono Cliffs Provincial Park", 44.0270, -80.0731);
        insertSampleLocation(db, "Forks of the Credit Provincial Park", 43.8017, -80.0014);
        insertSampleLocation(db, "Don Valley Brick Works", 43.6840, -79.3648);
        insertSampleLocation(db, "Toronto Botanical Garden", 43.7336, -79.3637);
    }


    /**
     * Helper method to insert a sample location (used for populateSampleData)
     */
    private void insertSampleLocation(SQLiteDatabase db, String address, double latitude, double longitude) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_ADDRESS, address);
        contentValues.put(COL_LATITUDE, latitude);
        contentValues.put(COL_LONGITUDE, longitude);
        db.insert(TABLE_NAME, null, contentValues);
    }
}











