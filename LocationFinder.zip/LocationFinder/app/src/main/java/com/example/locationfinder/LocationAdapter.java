package com.example.locationfinder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

/**
 * Adapter for displaying locations in a RecyclerView.
 */
public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {

    private ArrayList<Location> locationList;
    private Context context;

    public LocationAdapter(Context context, ArrayList<Location> locationList) {
        this.context = context;
        this.locationList = locationList != null ? locationList : new ArrayList<>();
    }

    @NonNull
    @Override
    public LocationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_location, parent, false);
        return new LocationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LocationViewHolder holder, int position) {
        Location location = locationList.get(position);
        holder.bind(location);
    }

    @Override
    public int getItemCount() {
        return locationList.size();
    }

    /**
     * ViewHolder class for binding location data to RecyclerView items.
     */
    static class LocationViewHolder extends RecyclerView.ViewHolder {
        private TextView idTextView, addressTextView, latitudeTextView, longitudeTextView;

        public LocationViewHolder(@NonNull View itemView) {
            super(itemView);
            idTextView = itemView.findViewById(R.id.idTextView); // TextView for displaying ID
            addressTextView = itemView.findViewById(R.id.addressTextView);
            latitudeTextView = itemView.findViewById(R.id.latitudeTextView);
            longitudeTextView = itemView.findViewById(R.id.longitudeTextView);
        }

        public void bind(Location location) {
            idTextView.setText("ID: " + location.getId());
            addressTextView.setText("Address: " + location.getAddress());
            latitudeTextView.setText("Latitude: " + location.getLatitude());
            longitudeTextView.setText("Longitude: " + location.getLongitude());
        }
    }
}



