package com.example.locationfinder;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.InputType;

public class MainActivity extends AppCompatActivity {

    // Declare variables for database helper and UI elements
    private DatabaseHelper db;
    private EditText editTextAddress, editTextLatitude, editTextLongitude, editTextId;
    private TextView textViewResult;
    private Button btnAdd, btnQuery, btnUpdate, btnDelete, btnViewAll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements and set up input validations and click listeners
        initializeViews();
        setupInputValidation();
        setupClickListeners();
    }

    // Method to initialize all UI elements and database helper
    private void initializeViews() {
        db = new DatabaseHelper(this);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextLatitude = findViewById(R.id.editTextLatitude);
        editTextLongitude = findViewById(R.id.editTextLongitude);
        editTextId = findViewById(R.id.editTextId);
        textViewResult = findViewById(R.id.textViewResult);

        // Initialize buttons for various actions
        btnAdd = findViewById(R.id.btnAdd);
        btnQuery = findViewById(R.id.btnQuery);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnViewAll = findViewById(R.id.btnViewAll);
    }

    // Set up input validation for latitude and longitude fields
    private void setupInputValidation() {
        editTextLatitude.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        editTextLongitude.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        // Filter latitude to ensure it's between -90 and 90
        editTextLatitude.setFilters(new InputFilter[]{(source, start, end, dest, dstart, dend) -> {
            try {
                float input = Float.parseFloat(dest.toString() + source.toString());
                if (input >= -90 && input <= 90) return null;
            } catch (NumberFormatException nfe) { }
            return "";
        }});

        // Filter longitude to ensure it's between -180 and 180
        editTextLongitude.setFilters(new InputFilter[]{(source, start, end, dest, dstart, dend) -> {
            try {
                float input = Float.parseFloat(dest.toString() + source.toString());
                if (input >= -180 && input <= 180) return null;
            } catch (NumberFormatException nfe) { }
            return "";
        }});
    }

    // Set up button click listeners for add, query, update, delete, and view actions
    private void setupClickListeners() {
        btnQuery.setOnClickListener(v -> handleQuery());
        btnAdd.setOnClickListener(v -> handleAdd());
        btnUpdate.setOnClickListener(v -> handleUpdate());
        btnDelete.setOnClickListener(v -> handleDelete());
        btnViewAll.setOnClickListener(v -> {
            // Navigate to ViewAllLocationsActivity when 'View All' button is clicked
            Intent intent = new Intent(MainActivity.this, ViewAllLocationsActivity.class);
            startActivity(intent);
        });
    }

    // Handle query operation based on address input
    private void handleQuery() {
        String address = editTextAddress.getText().toString().trim();
        if (!address.isEmpty()) {
            queryLocationByAddress(address);
        } else {
            showError("Please enter an address to search");
        }
    }

    // Handle add operation for new location entries
    private void handleAdd() {
        if (validateInputs(false)) {
            String address = editTextAddress.getText().toString().trim();
            double latitude = Double.parseDouble(editTextLatitude.getText().toString());
            double longitude = Double.parseDouble(editTextLongitude.getText().toString());

            // Insert location into database and provide feedback to the user
            if (db.insertLocation(address, latitude, longitude)) {
                showSuccess("Location added successfully");
                clearInputFields();
            } else {
                showError("Failed to add location. Address may already exist.");
            }
        }
    }

    // Handle update operation for existing location entries
    private void handleUpdate() {
        if (validateInputs(true)) {
            int id = Integer.parseInt(editTextId.getText().toString());
            String address = editTextAddress.getText().toString().trim();
            double latitude = Double.parseDouble(editTextLatitude.getText().toString());
            double longitude = Double.parseDouble(editTextLongitude.getText().toString());

            // Update location in database and provide feedback to the user
            if (db.updateLocation(id, address, latitude, longitude)) {
                showSuccess("Location updated successfully");
                clearInputFields();
            } else {
                showError("Failed to update location. ID may not exist.");
            }
        }
    }

    // Handle delete operation for location entries
    private void handleDelete() {
        String idStr = editTextId.getText().toString().trim();
        if (!idStr.isEmpty()) {
            showDeleteConfirmationDialog(Integer.parseInt(idStr));
        } else {
            showError("Please enter an ID to delete");
        }
    }

    // Validate inputs based on whether an ID is required
    private boolean validateInputs(boolean requireId) {
        if (requireId && TextUtils.isEmpty(editTextId.getText())) {
            showError("Please enter an ID");
            return false;
        }

        if (TextUtils.isEmpty(editTextAddress.getText())) {
            showError("Please enter an address");
            return false;
        }

        if (TextUtils.isEmpty(editTextLatitude.getText()) || TextUtils.isEmpty(editTextLongitude.getText())) {
            showError("Please enter both latitude and longitude");
            return false;
        }

        // Validate latitude and longitude values
        try {
            double lat = Double.parseDouble(editTextLatitude.getText().toString());
            double lng = Double.parseDouble(editTextLongitude.getText().toString());

            if (lat < -90 || lat > 90) {
                showError("Latitude must be between -90 and 90");
                return false;
            }
            if (lng < -180 || lng > 180) {
                showError("Longitude must be between -180 and 180");
                return false;
            }
        } catch (NumberFormatException e) {
            showError("Please enter valid coordinates");
            return false;
        }

        return true;
    }

    // Query location by address and display the result
    private void queryLocationByAddress(String address) {
        Cursor cursor = db.getLocationByAddress(address);
        if (cursor != null && cursor.moveToFirst()) {
            try {
                double latitude = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COL_LATITUDE));
                double longitude = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COL_LONGITUDE));
                displayLocationResult(address, latitude, longitude);
            } catch (Exception e) {
                showError("Error reading location data");
            } finally {
                cursor.close();
            }
        } else {
            textViewResult.setText("Location not found");
        }
    }

    // Display queried location details in the result text view
    private void displayLocationResult(String address, double latitude, double longitude) {
        String result = String.format("Location: %s\nLatitude: %.6f\nLongitude: %.6f", address, latitude, longitude);
        textViewResult.setText(result);
    }

    // Show confirmation dialog before deleting a location
    private void showDeleteConfirmationDialog(int id) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Location")
                .setMessage("Are you sure you want to delete this location?")
                .setPositiveButton("Yes", (dialog, which) -> deleteLocation(id))
                .setNegativeButton("No", null)
                .show();
    }

    // Delete location from database and provide feedback to the user
    private void deleteLocation(int id) {
        int rowsDeleted = db.deleteLocation(id);
        if (rowsDeleted > 0) {
            showSuccess("Location deleted successfully");
            clearInputFields();
        } else {
            showError("Failed to delete location. ID may not exist.");
        }
    }

    // Clear all input fields
    private void clearInputFields() {
        editTextAddress.setText("");
        editTextLatitude.setText("");
        editTextLongitude.setText("");
        editTextId.setText("");
    }

    // Show success message using a toast
    private void showSuccess(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // Show error message using a toast
    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}








